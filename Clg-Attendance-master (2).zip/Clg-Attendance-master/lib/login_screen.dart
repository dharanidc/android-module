import 'package:attendance_clg/Student/stu_dashboard.dart';
import 'package:attendance_clg/admin/admin_dashboard.dart';
import 'package:attendance_clg/common.dart';
import 'package:attendance_clg/teacher/teacher_dashboard.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController userTextEditingController =
  TextEditingController();
  final TextEditingController passwordTextEditingController =
  TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Colors.blue.shade800,
              Colors.white12,
              Colors.blue.shade800,
            ],
          ),
        ),
        padding: EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.electric_bolt_outlined,
                  color: Colors.blue[900],
                  size: 45,
                ),

                SizedBox(
                  width: 30,
                ),

                Text("SPARK INSTITUTE",
                  style: CommonStyles.blue18900(),
                )
              ],
            ),

            Column(
              children: [


                TextFormField(
                  controller: userTextEditingController,
                  style:CommonStyles.black15(),
                  decoration: InputDecoration(
                    hintText: "E - Mail ID",
                    labelText: "E - Mail ID",
                    labelStyle: CommonStyles.black15(),
                    hintStyle:  CommonStyles.black13thin(),

                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                TextFormField(
                  style:CommonStyles.black15(),

                  controller: passwordTextEditingController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: "Password",
                    labelText: "Password",
                    labelStyle: CommonStyles.black15(),
                    hintStyle:  CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
              ],
            ),
            Column(
              children: [
                ElevatedButton(
                    onPressed: () {
                      setState(() {

                        if(userTextEditingController.text.isNotEmpty &&
                            passwordTextEditingController.text.isNotEmpty
                        ){
                          if (userTextEditingController.text == 'admin' &&
                              passwordTextEditingController.text == 'admin') {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => AdminDashboard()));
                          }
                          if (userTextEditingController.text == 'student' &&
                              passwordTextEditingController.text == '123456') {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => StudentDashBoard()));
                          }

                          if (userTextEditingController.text == 'teacher' &&
                              passwordTextEditingController.text == '123456') {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => TeacherDashboard()));
                          }
                        }else{
                          showAlertDialog(context);
                        }

                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 70),
                      child: Text(
                          "Log In",
                          style:CommonStyles.whiteText18BoldW500()
                      ),
                    ),
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),
                SizedBox(
                  height: 10,
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: TextButton(
                      onPressed: () {
                        setState(() {
                          showAlertDialogBox(context);
                        });
                      },
                      child: Text(
                          "Forgot User name or Password ?",
                          style: CommonStyles.red12()
                      )),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Login Credentials !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your User Name and Password !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


  showAlertDialogBox(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "Send",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Forgot Password !!!",
        style: CommonStyles.black15(),
      ),
      content: TextFormField(
        style:CommonStyles.black15(),
        decoration: InputDecoration(
          hintText: "Enter your mail id",
          labelText: "E-Mail ID",
          labelStyle: CommonStyles.black12(),
          hintStyle:  CommonStyles.black12(),

          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(13)),
        ),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


}