import 'package:attendance_clg/common.dart';
import 'package:flutter/material.dart';

class StudentDashBoard extends StatefulWidget {
  const StudentDashBoard({super.key});

  @override
  State<StudentDashBoard> createState() => _StudentDashBoardState();
}

class _StudentDashBoardState extends State<StudentDashBoard> {
  final TextEditingController nameTextEditingCtroller = TextEditingController();
  final TextEditingController cidTextEditingCtroller = TextEditingController();
  final TextEditingController rnoTextEditingCtroller = TextEditingController();

  List<String> status = [
    "Present",
    "Present",
    "Absent",
    "Present",
    "Absent",
    "Present",
  ];
  List<String> date = [
    "03-01-2024",
    "04-01-2024",
    "05-01-2024",
    "06-01-2024",
    "07-01-2024",
    "08-01-2024",
  ];

  bool visible = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Student Dashboard',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: false,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Colors.lightBlue.shade300,
                Colors.white12,
                Colors.lightBlue.shade300,
              ],
            )),
          )),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(
              child: Text(
                "View Student Attendance",
                style: CommonStyles.blue14900(),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "Student Name",
              style: CommonStyles.blue14900(),
            ),
            SizedBox(
              height: 10,
            ),
            TextFormField(
              style: CommonStyles.black13(),
              controller: nameTextEditingCtroller,
              decoration: InputDecoration(
                hintText: "Student name",
                hintStyle: CommonStyles.black12(),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "Course ID",
              style: CommonStyles.blue14900(),
            ),
            SizedBox(
              height: 10,
            ),
            TextFormField(
              style: CommonStyles.black13(),
              controller: cidTextEditingCtroller,

              decoration: InputDecoration(
                hintText: "Course ID",
                hintStyle: CommonStyles.black12(),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "Register Number",
              style: CommonStyles.blue14900(),
            ),
            SizedBox(
              height: 10,
            ),
            TextFormField(
              style: CommonStyles.black13(),
              controller: rnoTextEditingCtroller,

              decoration: InputDecoration(
                hintText: "Register Number",
                hintStyle: CommonStyles.black12(),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Center(
              child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                    if(  nameTextEditingCtroller.text.isNotEmpty&&
                      cidTextEditingCtroller.text.isNotEmpty&&
                      rnoTextEditingCtroller.text.isNotEmpty ){
                      setState(() {
                        visible = !visible;

                      });
                    }else{
                      showAlerErrortDialog(context);
                    }

                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 50),
                    child: Text("View Attendance",
                        style: CommonStyles.whiteText18BoldW500()),
                  ),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.green),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(color: Colors.blue))))),
            ),
            SizedBox(
              height: 30,
            ),
            if (visible == true)
              Column(
                children: [
                  Text(
                    "Course Attendance",
                    style: CommonStyles.blue14900(),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        "Student Name  : ",
                        style: CommonStyles.blue14900(),
                      ), Text(
                        nameTextEditingCtroller.text,
                        style: CommonStyles.black15(),
                      ),
                    ],
                  ), SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        "Course ID  : ",
                        style: CommonStyles.blue14900(),
                      ),
                      Text(
                        cidTextEditingCtroller.text,
                        style: CommonStyles.blue14900(),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        "Register No  : ",
                        style: CommonStyles.blue14900(),
                      ),
                      Text(
                        rnoTextEditingCtroller.text,
                        style: CommonStyles.blue14900(),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),


                  Row(
                    children: [

                      Expanded(child: Text("S.No",
                      style: CommonStyles.black14(),
                      )),

                      SizedBox(width: 16),

                      Expanded(child: Text("Status",
                      style: CommonStyles.black14(),
                      )),

                      SizedBox(width: 16),

                      Expanded(
                          child: Text(
                        "Date",
                        style: CommonStyles.black14(),
                      )),

                      SizedBox(width: 16),
                    ],
                  ),

                  SizedBox(
                    height: 15,
                  )
                ],
              ),
            if (visible == true)
              ListView.builder(
                  itemCount: status.length,
                  shrinkWrap: true,
                  primary: false, // Number of rows
                  itemBuilder: (BuildContext context, int rowIndex) {
                    return Row(children: [
                      Expanded(
                        child: Container(
                          color: (status[rowIndex] == 'Present')
                              ? Colors.green
                              : Colors.red,
                          height: 40,
                          child: Center(
                            child: Text(
                              "${rowIndex + 1}",
                              style: CommonStyles.whiteText13BoldW500()

                            ),
                          ),
                        ),
                      ),

                      SizedBox(width: 16),
                      Expanded(
                        flex: 2,
                        child: Container(
                          color: (status[rowIndex] == 'Present')
                              ? Colors.green
                              : Colors.red,
                          height: 40,
                          child: Center(
                            child: Text(
                              status[rowIndex],
                                style: CommonStyles.whiteText13BoldW500()

                            ),
                          ),
                        ),
                      ),
                      // Second Column
                      SizedBox(width: 16),
                      // Add some spacing between columns
                      Expanded(
                        flex: 2,
                        child: Container(
                          color: (status[rowIndex] == 'Present')
                              ? Colors.green
                              : Colors.red,
                          height: 40,
                          child: Center(
                            child: Text(
                              date[rowIndex],
                              style: CommonStyles.whiteText13BoldW500()
                            ),
                          ),
                        ),
                      ),
                    ]);
                  })
          ]),
        ),
      ),
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create Student !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your Enter Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

}
