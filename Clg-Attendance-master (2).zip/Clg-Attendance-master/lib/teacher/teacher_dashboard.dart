import 'package:attendance_clg/common.dart';
import 'package:attendance_clg/login_screen.dart';
import 'package:attendance_clg/teacher/attendance_screen.dart';
import 'package:attendance_clg/teacher/student_screen.dart';
import 'package:flutter/material.dart';


class TeacherDashboard extends StatefulWidget {
  const TeacherDashboard({super.key});

  @override
  State<TeacherDashboard> createState() => _TeacherDashboardState();
}

class _TeacherDashboardState extends State<TeacherDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Teacher Dashboard',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: false,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    Colors.lightBlue.shade300,
                    Colors.white12,
                    Colors.lightBlue.shade300,
                  ],
                )),
          )),
        body: Container(
          padding: EdgeInsets.all(20),
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Text("Students".toUpperCase(),
                style: CommonStyles.blue14900(),
                ),

            SizedBox(
              height: 20,
            ),
            Padding(
            padding: const EdgeInsets.all(8.0),
            child: InkWell(
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=> ManageStudentScreen()));
              },
              child: Card(
                color: Colors.white,
                shadowColor: Colors.white,
                elevation: 10,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Manage Students",
                            style: CommonStyles.black15(),
                          ),
                          IconButton(onPressed: (){}, icon: Icon(Icons.people_alt_outlined,

                            size: 45,
                            color: Colors.blueAccent ,
                          ))
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
        ),
                SizedBox(
                  height: 50,
                ),

      Text("Attendance".toUpperCase(),
        style: CommonStyles.blue14900(),
      ),

      SizedBox(
        height: 20,
      ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: InkWell(
            onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=> ManageAttendanceScren()));
            },
            child: Card(
              color: Colors.white,
              shadowColor: Colors.white,
              elevation: 10,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Manage Attendance",
                          style: CommonStyles.black15(),
                        ),
                        IconButton(onPressed: (){}, icon: Icon(Icons.event_available_rounded,

                          size: 45,
                          color: Colors.blueAccent ,
                        ))
                      ],
                    )
                  ],
                ),
              ),
            ),)),

                SizedBox(
                  height: 70,
                ),

                Center(
                  child: Text("Cloud Computing",
                  style: CommonStyles.green15(),
                  ),
                ),

                SizedBox(
                  height: 30,
                ),

                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      color: Colors.white,
                      shadowColor: Colors.white,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Students",
                                      style: CommonStyles.black15(),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text("8",
                                      style: CommonStyles.black15(),
                                    ),
                                  ],
                                ),
                                IconButton(onPressed: (){}, icon: Icon(Icons.event_available_rounded,

                                  size: 45,
                                  color: Colors.blueAccent ,
                                ))
                              ],
                            )
                          ],
                        ),
                      ),
                    )), SizedBox(
                  height: 20
                ),
                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      color: Colors.white,
                      shadowColor: Colors.white,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Classes",
                                      style: CommonStyles.black15(),
                                    ),
                                    SizedBox(height: 10),
                                      Text("5",
                                        style: CommonStyles.black15(),

                                    )
                                  ],
                                ),
                                IconButton(onPressed: (){}, icon: Icon(Icons.event_available_rounded,

                                  size: 45,
                                  color: Colors.blueAccent ,
                                ))
                              ],
                            )
                          ],
                        ),
                      ),
                    )), SizedBox(
                  height: 20,
                ),
                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      color: Colors.white,
                      shadowColor: Colors.white,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("Manage Attendance",
                                  style: CommonStyles.black15(),
                                ),
                                IconButton(onPressed: (){}, icon: Icon(Icons.event_available_rounded,

                                  size: 45,
                                  color: Colors.blueAccent ,
                                ))
                              ],
                            )
                          ],
                        ),
                      ),
                    )), SizedBox(
                  height: 20,
                ),
                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      color: Colors.white,
                      shadowColor: Colors.white,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  children: [
                                    Text("Students",
                                      style: CommonStyles.black15(),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text("8",
                                      style: CommonStyles.black15(),
                                    ),
                                  ],
                                ),
                                IconButton(onPressed: (){}, icon: Icon(Icons.people_alt,

                                  size: 45,
                                  color: Colors.blueAccent ,
                                ))
                              ],
                            )
                          ],
                        ),
                      ),
                    )),



                SizedBox(
                  height: 60,
                ),

                Center(
                  child: TextButton(onPressed: (){
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => LoginScreen()),
                          (route) => false, // Keep removing routes until this condition is met
                    );

                  }, child: Text("Log Out",
                    style: CommonStyles.red15(),
                  )),
                )

              ],
            ),
          ),
        ),
    );
  }
}
