import 'package:attendance_clg/common.dart';
import 'package:attendance_clg/admin/model/create_stu_model.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class CreateStudentScreen extends StatefulWidget {
  const CreateStudentScreen({super.key});

  @override
  State<CreateStudentScreen> createState() => _CreateStudentScreenState();
}

class _CreateStudentScreenState extends State<CreateStudentScreen> {


  final TextEditingController fnameTextCntrl = TextEditingController();
  final TextEditingController lnameTextCntrl = TextEditingController();
  final TextEditingController emailnameTextCntrl = TextEditingController();
  final TextEditingController regNoTextCntrl = TextEditingController();
  final TextEditingController coursenameTextCntrl = TextEditingController();
  final TextEditingController courseIdTextCntrl = TextEditingController();


  DataModelClass _model = DataModelClass();


  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model.saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create Student !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Are you sure to create Student !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Manage Students',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: true,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    Colors.lightBlue.shade300,
                    Colors.white12,
                    Colors.lightBlue.shade300,
                  ],
                )),
          )),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                "First Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: fnameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "First Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Last Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: lnameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Last Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Email address",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: emailnameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Email Address",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Register Number",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: regNoTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Register Number",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Course Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: coursenameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Course Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Course Id",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: courseIdTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Course Id",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Center(
                child: ElevatedButton(
                    onPressed: () async{

                        if (fnameTextCntrl.text != null &&
                            fnameTextCntrl.text.isNotEmpty &&
                            lnameTextCntrl.text != null &&
                            lnameTextCntrl.text.isNotEmpty &&
                            emailnameTextCntrl.text != null &&
                            emailnameTextCntrl.text.isNotEmpty &&
                            regNoTextCntrl.text != null &&
                            regNoTextCntrl.text.isNotEmpty &&
                            coursenameTextCntrl.text != null &&
                            coursenameTextCntrl.text.isNotEmpty &&
                            courseIdTextCntrl.text != null &&
                            courseIdTextCntrl.text.isNotEmpty) {


                          _model.fname.add(fnameTextCntrl.text);
                          _model.lname.add(lnameTextCntrl.text);
                          _model.email.add(emailnameTextCntrl.text);
                          _model.regNo.add(regNoTextCntrl.text);
                          _model.cname.add(coursenameTextCntrl.text);
                          _model.cId.add(courseIdTextCntrl.text);


                          await _model.saveData();

                          await _model.createStudentData();

                          fnameTextCntrl.clear();
                          lnameTextCntrl.clear();
                          emailnameTextCntrl.clear();
                          regNoTextCntrl.clear();
                          coursenameTextCntrl.clear();
                          courseIdTextCntrl.clear();


                          showAlertDialog(context);
                        } else {
                          showAlerErrortDialog(context);
                        }

                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: Text("Create Faculty",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                        MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),
              ),
              SizedBox(
                height: 50,
              ),
              Center(
                child: Text(
                  "Student and More Details : ",
                  style: CommonStyles.blue14900(),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              ListView.builder(
                  primary: false,
                  shrinkWrap: true,
                  itemCount: _model.fname.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10.0),
                      child: Card(
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              vertical: 10, horizontal: 10),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "First Name",
                                        style: CommonStyles.green12(),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        _model.fname[index],
                                        style: CommonStyles.black13thin(),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Last Name",
                                        style: CommonStyles.green12(),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        _model.lname[index],
                                        style: CommonStyles.black13thin(),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "E Mail Address",
                                        style: CommonStyles.green12(),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        _model.email[index],
                                        style: CommonStyles.black13thin(),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Register Number",
                                        style: CommonStyles.green12(),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        _model.regNo[index],
                                        style: CommonStyles.black13thin(),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Course Name",
                                        style: CommonStyles.green12(),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        _model.cname[index],
                                        style: CommonStyles.black13thin(),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Course Id",
                                        style: CommonStyles.green12(),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        _model.cId[index],
                                        style: CommonStyles.black13thin(),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              IconButton(
                                  onPressed: () {
                                    setState(() {
                                      _model.fname.removeAt(index);
                                      _model.lname.removeAt(index);
                                      _model.email.removeAt(index);
                                      _model.regNo.removeAt(index);
                                      _model.cname.removeAt(index);
                                      _model.cId.removeAt(index);
                                    });
                                  },
                                  icon: Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                  )),
                            ],
                          ),
                        ),
                      ),
                    );
                  })
            ],
          ),
        ),
      ),
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create Student !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your Enter Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}

