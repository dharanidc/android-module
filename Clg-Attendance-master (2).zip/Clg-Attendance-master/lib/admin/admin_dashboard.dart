import 'package:attendance_clg/admin/course_screen.dart';
import 'package:attendance_clg/admin/create_course_screen.dart';
import 'package:attendance_clg/admin/create_student_screen.dart';
import 'package:attendance_clg/admin/faculty_screen.dart';
import 'package:attendance_clg/common.dart';
import 'package:attendance_clg/login_screen.dart';
import 'package:flutter/material.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  List<String> dashboard = [
    "Manage Course",
    "Course",
    "Manage Faculty",
    "Manage Students"
  ];

  List<IconData> icon = [

    Icons.golf_course_outlined,
    Icons.radar_outlined,
    Icons.access_time_rounded,
    Icons.people_alt_outlined
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Admin Dashboard',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: false,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Colors.lightBlue.shade300,
                Colors.white12,
                Colors.lightBlue.shade300,
              ],
            )),
          )),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        child: Column(
          children: [
            ListView.builder(
              itemCount: dashboard.length,
              shrinkWrap: true,
              primary: false,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: (){
                    if(index == 0)  Navigator.of(context).push(MaterialPageRoute(builder: (context)=> CourseScreen()));
                    if(index == 1)  Navigator.of(context).push(MaterialPageRoute(builder: (context)=> CreateCourseScreen()));
                    if(index == 2)  Navigator.of(context).push(MaterialPageRoute(builder: (context)=> FacultyScreen()));
                    if(index == 3)  Navigator.of(context).push(MaterialPageRoute(builder: (context)=> CreateStudentScreen()));
                    },
                    child: Card(
                      color: Colors.white,
                      shadowColor: Colors.white,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)
                      ),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                        child: Column(
                          children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(dashboard[index],
                              style: CommonStyles.black15(),
                              ),
                              IconButton(onPressed: (){}, icon: Icon(icon[index],

                              size: 45,
                                color: Colors.blueAccent ,
                              ))
                            ],
                          )
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }
            ),

            SizedBox(
              height: 60,
            ),

            TextButton(onPressed: (){
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => LoginScreen()),
                    (route) => false, // Keep removing routes until this condition is met
              );

            }, child: Text("Log Out",
            style: CommonStyles.red15(),
            ))

          ],
        ),
      ),
    );
  }
}
