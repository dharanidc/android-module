import 'package:shared_preferences/shared_preferences.dart';

class CourseModel {

  List<String> addCourse = [];
  List<String> addCourseId = [];


  Future<void> createCourseData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    addCourse = prefs.getStringList('course') ?? [];
    addCourseId = prefs.getStringList('cid') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('course', addCourse);
    prefs.setStringList('cid', addCourseId);

  }
}