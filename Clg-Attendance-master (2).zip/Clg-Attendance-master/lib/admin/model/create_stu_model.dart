import 'package:shared_preferences/shared_preferences.dart';

class DataModelClass {
// Create Student

  List<String> fname = [];
  List<String> lname = [];
  List<String> email = [];

  List<String> cname = [];
  List<String> cId = [];
  List<String> regNo = [];

  Future<void> createStudentData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    fname = prefs.getStringList('fname') ?? [];
    lname = prefs.getStringList('lname') ?? [];
    email = prefs.getStringList('email') ?? [];
    regNo = prefs.getStringList('regNo') ?? [];
    cname = prefs.getStringList('cname') ?? [];
    cId = prefs.getStringList('cId') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('fname', fname);
    prefs.setStringList('lname', lname);
    prefs.setStringList('email', email);
    prefs.setStringList('regNo', regNo);
    prefs.setStringList('cname', cname);
    prefs.setStringList('cId', cId);
  }
}
