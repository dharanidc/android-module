import 'package:shared_preferences/shared_preferences.dart';

class FacultyModel {
// Create Student

  List<String> finame = [];
  List<String> laname = [];
  List<String> emailid = [];
  List<String> coname = [];
  List<String> coId = [];
  List<String> phno = [];

  Future<void> createFacultyData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    finame = prefs.getStringList('finame') ?? [];
    laname = prefs.getStringList('laname') ?? [];
    emailid = prefs.getStringList('emailid') ?? [];
    phno = prefs.getStringList('phno') ?? [];
    coname = prefs.getStringList('coname') ?? [];
    coId = prefs.getStringList('coId') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('finame', finame);
    prefs.setStringList('laname', laname);
    prefs.setStringList('emailid', emailid);
    prefs.setStringList('phno', phno);
    prefs.setStringList('coname', coname);
    prefs.setStringList('coId', coId);
  }
}
