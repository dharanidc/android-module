import 'package:attendance_clg/admin/model/create_faculty_model.dart';
import 'package:attendance_clg/common.dart';
import 'package:flutter/material.dart';

class FacultyScreen extends StatefulWidget {
  const FacultyScreen({super.key});

  @override
  State<FacultyScreen> createState() => _FacultyScreenState();
}

class _FacultyScreenState extends State<FacultyScreen> {

  final TextEditingController fnameTextCntrl = TextEditingController();
  final TextEditingController lnameTextCntrl = TextEditingController();
  final TextEditingController emailnameTextCntrl = TextEditingController();
  final TextEditingController phnonameTextCntrl = TextEditingController();
  final TextEditingController coursenameTextCntrl = TextEditingController();
  final TextEditingController courseIdTextCntrl = TextEditingController();

  FacultyModel _model = FacultyModel();

  Future<void> _initData() async {
    await _model.createFacultyData();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
  }

  @override
  void dispose() {
    _model.saveData();
    super.dispose();
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create Faculty !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Faculty will added Sucessfully !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Manage Faculty',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: true,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Colors.lightBlue.shade300,
                Colors.white12,
                Colors.lightBlue.shade300,
              ],
            )),
          )),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                "First Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: fnameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "First Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Last Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: lnameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Last Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Email address",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: emailnameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Email Address",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Phone Number",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: phnonameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Phone Number",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Course Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: coursenameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Course Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Course Id",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: courseIdTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Course Id",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Center(
                child: ElevatedButton(
                    onPressed: () async {
                      if (fnameTextCntrl.text != null &&
                          fnameTextCntrl.text.isNotEmpty &&
                          lnameTextCntrl.text != null &&
                          lnameTextCntrl.text.isNotEmpty &&
                          emailnameTextCntrl.text != null &&
                          emailnameTextCntrl.text.isNotEmpty &&
                          phnonameTextCntrl.text != null &&
                          phnonameTextCntrl.text.isNotEmpty &&
                          coursenameTextCntrl.text != null &&
                          coursenameTextCntrl.text.isNotEmpty &&
                          courseIdTextCntrl.text != null &&
                          courseIdTextCntrl.text.isNotEmpty) {
                        _model.finame.add(fnameTextCntrl.text);
                        _model.laname.add(lnameTextCntrl.text);
                        _model.emailid.add(emailnameTextCntrl.text);
                        _model.phno.add(phnonameTextCntrl.text);
                        _model.coname.add(coursenameTextCntrl.text);
                        _model.coId.add(courseIdTextCntrl.text);

                        await _model.saveData();

                        await _model.createFacultyData();

                        fnameTextCntrl.clear();
                        lnameTextCntrl.clear();
                        emailnameTextCntrl.clear();
                        phnonameTextCntrl.clear();
                        coursenameTextCntrl.clear();
                        courseIdTextCntrl.clear();

                        setState(() {});

                        showAlertDialog(context);
                      } else {
                        showAlerErrortDialog(context);
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: Text("Create Faculty",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
              ),
              SizedBox(
                height: 50,
              ),
              Center(
                child: Text(
                  "Faculty and More Details : ",
                  style: CommonStyles.blue14900(),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              if (_model.finame.length > 0)
                ListView.builder(
                    primary: false,
                    shrinkWrap: true,
                    itemCount: _model.finame.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                        child: Card(
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 10, horizontal: 10),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "First Name",
                                          style: CommonStyles.green12(),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          _model.finame[index],
                                          style: CommonStyles.black13thin(),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Last Name",
                                          style: CommonStyles.green12(),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          _model.laname[index],
                                          style: CommonStyles.black13thin(),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "E Mail Address",
                                          style: CommonStyles.green12(),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          _model.emailid[index],
                                          style: CommonStyles.black13thin(),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Phone Number",
                                          style: CommonStyles.green12(),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          _model.phno[index],
                                          style: CommonStyles.black13thin(),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Course Name",
                                          style: CommonStyles.green12(),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          _model.coname[index],
                                          style: CommonStyles.black13thin(),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Course Id",
                                          style: CommonStyles.green12(),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          _model.coId[index],
                                          style: CommonStyles.black13thin(),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                IconButton(
                                    onPressed: () {
                                      setState(() {
                                        _model.finame.removeAt(index);
                                        _model.laname.removeAt(index);
                                        _model.emailid.removeAt(index);
                                        _model.phno.removeAt(index);
                                        _model.coname.removeAt(index);
                                        _model.coId.removeAt(index);
                                      });
                                    },
                                    icon: Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    )),
                              ],
                            ),
                          ),
                        ),
                      );
                    })
            ],
          ),
        ),
      ),
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create Faculty !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your Enter Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
