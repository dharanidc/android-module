import 'package:attendance_clg/admin/model/create_course_model.dart';
import 'package:attendance_clg/common.dart';
import 'package:flutter/material.dart';

class CreateCourseScreen extends StatefulWidget {
  const CreateCourseScreen({super.key});

  @override
  State<CreateCourseScreen> createState() => _CreateCourseScreenState();
}

class _CreateCourseScreenState extends State<CreateCourseScreen> {
  final TextEditingController idTextCntrl = TextEditingController();
  final TextEditingController nameTextCntrl = TextEditingController();

  CourseModel _model = CourseModel();

  Future<void> _initData() async {
    await _model.createCourseData();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
  }

  @override
  void dispose() {
    _model.saveData();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Create Course',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: true,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Colors.lightBlue.shade300,
                Colors.white12,
                Colors.lightBlue.shade300,
              ],
            )),
          )),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                "Course Name",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: nameTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Course Name",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Course Id",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: idTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Course Id",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Center(
                child: ElevatedButton(
                    onPressed: () async {
                      if (nameTextCntrl.text.isNotEmpty &&
                          idTextCntrl.text.isNotEmpty) {
                        _model.addCourse.add(nameTextCntrl.text);
                        _model.addCourseId.add(idTextCntrl.text);

                        await _model.saveData();

                        await _model.createCourseData();

                        nameTextCntrl.clear();
                        idTextCntrl.clear();
                        showAlertDialog(context);

                        setState(() {});
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: Text("Create Course",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
              ),
              SizedBox(
                height: 50,
              ),
              Center(
                child: Text(
                  "All Course",
                  style: CommonStyles.blue14900(),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              if (_model.addCourse.length != 0)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Center(
                        child: Text(
                          "S.No",
                          style: CommonStyles.red12(),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Center(
                        child: Text(
                          "Course Name",
                          style: CommonStyles.red12(),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Center(
                        child: Text(
                          "Action",
                          style: CommonStyles.red12(),
                        ),
                      ),
                    ),
                  ],
                ),
              SizedBox(
                height: 20,
              ),
              _model.addCourse.length != 0
                  ? ListView.builder(
                      shrinkWrap: true,
                      primary: false,
                      itemCount: _model.addCourse.length, // Number of rows
                      itemBuilder: (BuildContext context, int rowIndex) {
                        return Row(
                          children: [
                            // First Column
                            Expanded(
                              child: Container(
                                color: (rowIndex % 2 == 0)
                                    ? Colors.green
                                    : Colors.red,
                                height: 50,
                                child: Center(
                                  child: Text(
                                    "${rowIndex + 1}".toString(),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                            // Second Column
                            SizedBox(
                                width: 16), // Add some spacing between columns
                            Expanded(
                              flex: 4,
                              child: Container(
                                color: (rowIndex % 2 == 0)
                                    ? Colors.green
                                    : Colors.red,
                                height: 50,
                                child: Center(
                                  child: Text(
                                    _model.addCourse[rowIndex],
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                            IconButton(
                              icon: Icon(
                                Icons.delete,
                                color: Colors.red,
                              ),
                              onPressed: () {
                                setState(() {
                                  _model.addCourse.removeAt(rowIndex);
                                });
                              },
                            )
                          ],
                        );
                      },
                    )
                  : Center(
                      child: Text(
                        "No Course Added !!!!",
                        style: CommonStyles.red15(),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create Course !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Course added Sucessfully !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
