import 'package:attendance_clg/admin/create_course_screen.dart';
import 'package:attendance_clg/common.dart';
import 'package:flutter/material.dart';

class CourseScreen extends StatefulWidget {
  const CourseScreen({super.key});

  @override
  State<CourseScreen> createState() => _CourseScreenState();
}

class _CourseScreenState extends State<CourseScreen> {
  List<String> course = [
    'Students',
    'Courses',
    'Course ID',
    'Total Student\n Attendance',
    'Faculty'
  ];

  List<String> count = ['32', '8', '13', '81', '7'];

  List<IconData> icon = [
    Icons.people_alt_outlined,
    Icons.computer,
    Icons.usb_outlined,
    Icons.calendar_month,
    Icons.account_box
  ];

  List<Color> color = [
    Colors.tealAccent,
    Colors.purple,
    Colors.green,
    Colors.orangeAccent,
    Colors.red,
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            'Manage Course',
            style: CommonStyles.blue18900(),
          ),
          automaticallyImplyLeading: true,
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Colors.lightBlue.shade300,
                Colors.white12,
                Colors.lightBlue.shade300,
              ],
            )),
          )),
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        child: Column(
          children: [
            Card(
              color: Colors.lightGreenAccent,
              shadowColor: Colors.white,
              elevation: 10,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Create Course",
                                style: CommonStyles.black15(),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                            ],
                          ),
                          IconButton(
                              onPressed: () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (context) =>
                                        CreateCourseScreen()));
                              },
                              icon: Icon(
                                Icons.arrow_forward_ios_rounded,
                                size: 35,
                                color: Colors.black87,
                              ))
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ListView.builder(
                itemCount: course.length,
                shrinkWrap: true,
                primary: false,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Card(
                      color: Colors.white,
                      shadowColor: Colors.white,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      child: Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                        child: Column(
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 18.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        course[index],
                                        style: CommonStyles.black15(),
                                      ),
                                      SizedBox(
                                        height: 8,
                                      ),
                                      Text(
                                        count[index],
                                        style: CommonStyles.black15(),
                                      ),
                                    ],
                                  ),
                                  IconButton(
                                      onPressed: () {},
                                      icon: Icon(
                                        icon[index],
                                        size: 35,
                                        color: color[index],
                                      ))
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                }),
          ],
        ),
      ),
    );
  }
}
