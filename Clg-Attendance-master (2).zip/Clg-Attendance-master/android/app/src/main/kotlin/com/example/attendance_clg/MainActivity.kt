package com.example.attendance_clg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
